// src/domain/servicios/ProfesorService.js
const db = require("../../shared/config/database"); // Importamos los modelos
const Estudiante = db.Estudiante; // Aseguramos que estamos usando el modelo importado correctamente
const Programa = db.Programa;
const Materia = db.Materia;
const Profesor = db.Profesor;

class ProfesorDomain {
  // Método para obtener todas las materias de un profesor
  static async obtenerMaterias(profesorId) {
    const profesor = await Profesor.findByPk(profesorId, {
      include: {
        model: Materia,
        as: 'materias',
        include: {
          model: Estudiante,
          as: 'estudiantes',
        },
      },
    });

    if (!profesor) {
      throw new Error('Profesor no encontrado');
    }

    return profesor.materias.map(materia => ({
      nombreMateria: materia.nombre,
      estudiantes: materia.estudiantes.map(est => ({
        nombre: est.nombre,
        pais_residencia: est.pais_residencia,
      })),
    }));
  }

  // Método para obtener todos los profesores (usando Sequelize)
  static async obtenerTodos() {
    const result = await Profesor.findAll({
      include: {
        model: Materia,
        as: 'materias',
        include: {
          model: Estudiante,
          as: 'estudiantes',
        },
      },
    });

    return result
  }
}

module.exports = ProfesorDomain;
