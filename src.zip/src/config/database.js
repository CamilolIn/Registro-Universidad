module.exports = {
    host: 'localhost',
    username: 'root',
    password: '',
    database: 'universidad',
    dialect: 'mysql',
  };